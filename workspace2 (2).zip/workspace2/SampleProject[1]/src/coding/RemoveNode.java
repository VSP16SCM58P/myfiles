package coding;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RemoveNode extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static Scanner file;
	static int rows;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		ArrayList<ArrayList<Integer>> data = new ArrayList<ArrayList<Integer>>();
		//PrintWriter out = response.getWriter();
		//int row = (int) request.getSession().getAttribute("row");
		String path = (String) request.getServletContext().getAttribute("Upload_Directory");
		int[][] matrix = (int[][]) request.getServletContext().getAttribute("message");
		int deleteNode;
		
		deleteNode= Integer.parseInt(request.getParameter("DeleteRouter"));
		//System.out.println("Path::"+name);
		//int routerN = name;
//		deletedList.add(deleteNode);
//		for(int i=0;i<deletedList.size();i++)
//		{
//			System.out.println("DeletedList"+deletedList.get(i));
//		}
		String line = null;
		int lineCount=0;

		BufferedReader br = new BufferedReader(new FileReader(path));
		while((line=br.readLine())!=null){
			lineCount++;
		}
		
		ModifyMatrix modifyMatrix=new ModifyMatrix();
		int modified_matrix[][]=modifyMatrix.modifiedMatrix(matrix, deleteNode-1);
		for(int i=0;i<modified_matrix.length;i++)
		{
			for(int j=0;j<modified_matrix.length;j++)
			{
				//System.out.println(modified_matrix[i][j]);
			}
		}

		request.setAttribute("Count", lineCount);
		request.getServletContext().setAttribute("rdelete", deleteNode);
		request.getServletContext().setAttribute("message",modified_matrix);
		//    request.setAttribute("routerList", routers);
		//    request.setAttribute("edgesList", edges);

		request.getRequestDispatcher("/NodeRemoval.jsp").forward(request, response);
	}


}
