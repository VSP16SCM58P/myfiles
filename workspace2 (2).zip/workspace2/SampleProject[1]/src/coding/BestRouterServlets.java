package coding;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BestRouterServlets
 */
public class BestRouterServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BestRouterServlets() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		ArrayList<ArrayList<Integer>> data = new ArrayList<ArrayList<Integer>>();
		//PrintWriter out = response.getWriter();
		//int row = (int) request.getSession().getAttribute("row");
		String path = (String) request.getServletContext().getAttribute("Upload_Directory");
		int[][] matrix = (int[][]) request.getServletContext().getAttribute("message");
		int edgeValue1=Integer.parseInt(request.getParameter("No1"));
		int edgeValue2=Integer.parseInt(request.getParameter("No2"));
		int cost=Integer.parseInt(request.getParameter("cost"));
		
		String line = null;
		int lineCount=0;
		Scanner fileScanner = new Scanner(new File(path));
		BufferedReader br = new BufferedReader(new FileReader(path));
		while((line=br.readLine())!=null){
			lineCount++;
		}
		int newMatrix[][]=new int[matrix.length][matrix.length];
		EdgeModificationClass edgeModificationClass=new EdgeModificationClass();
		//edgeModificationClass.edgeModification(matrix, edgeValue1, edgeValue2, cost);
		
		request.getServletContext().setAttribute("message",edgeModificationClass.edgeModification(matrix, edgeValue1, edgeValue2, cost));
		

		request.getRequestDispatcher("/EdgeUpdated.jsp").forward(request, response);
	}

}
