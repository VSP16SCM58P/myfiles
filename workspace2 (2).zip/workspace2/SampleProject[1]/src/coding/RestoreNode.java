package coding;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RestoreNode
 */
public class RestoreNode extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RestoreNode() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		ArrayList<ArrayList<Integer>> data = new ArrayList<ArrayList<Integer>>();
		//PrintWriter out = response.getWriter();
		//int row = (int) request.getSession().getAttribute("row");
		String path = (String) request.getServletContext().getAttribute("Upload_Directory");
		int[][] matrix = (int[][]) request.getServletContext().getAttribute("message");
		int deleteNode;
		//deleteNode= Integer.parseInt(request.getParameter("DeleteRouter"));
		int rdelete=Integer.parseInt(request.getParameter("deletednode"));
		int[][] old_matrix = new int[matrix.length][matrix.length];
		//System.out.println("Path::"+name);
		//int routerN = name;
		String line = null;
		int lineCount=0;
		Scanner fileScanner = new Scanner(new File(path));
		BufferedReader br = new BufferedReader(new FileReader(path));
		while((line=br.readLine())!=null){
			lineCount++;
		}
		
		int lineC = 0;
		while (fileScanner.hasNextLine()) {
			  String[] currentLine = fileScanner.nextLine().trim().split("\\s+"); 
			     for (int i = 0; i < currentLine.length; i++) {
			    	 //System.out.println("Data:"+currentLine[1]);
			        old_matrix[lineC][i] = Integer.parseInt(currentLine[i]);    
			            }
			  lineC++;
			 }       
		for(int x=0;x<matrix.length;x++){
			for(int y=0;y<matrix.length;y++){
				//System.out.println("OLD MATRIX::"+old_matrix[x][y]);
			}
		}
		MatrixRestore matrixRestore=new MatrixRestore();
		int old_modified_matrix[][]=matrixRestore.matrixRestoreWithRouter(old_matrix, matrix, rdelete-1);
		request.setAttribute("Count", lineCount);
		request.getServletContext().setAttribute("rdelete", rdelete);
		request.getServletContext().setAttribute("message",old_modified_matrix);
		//    request.setAttribute("routerList", routers);
		//    request.setAttribute("edgesList", edges);

		request.getRequestDispatcher("/NodeRemoval.jsp").forward(request, response);
	}

}
