package coding;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class FindShortestPath {
	/**
	 * Method to display the shortest path between the source and the destination routers
	 * @param input_matrix
	 * @param source
	 * @param destination
	 * @return
	 */
	public Object dijkstras(int[][] input_matrix, int source, int destination){

		try{
			int index = source;
			int counter = 0 ;
			int k = 1; 
			List<Object> ls = new ArrayList<Object>();
			LinkedList<Object> al=new LinkedList<Object>();  
			//Array to hold all the distances from source to destination
			int[] distance_array =new int[5];

			boolean[] visit_array = new boolean[5];

			int[] path_array = new int[5];
			System.out.println();
			//Initialize all the elements of path_array to source(or any value)
			//			for (int i = 0; i < path_array.length; i++) 
			//			{
			//				path_array[i] = source;
			//			}
			int i=0;
			while(i<path_array.length)
			{
				path_array[i]=source;
				System.out.println("OOOOOOO"+path_array[i]);
				i++;
			}

			//Initialize true for source in the visit-array
			visit_array[index] = true;

			//Repeat till the maximum number of elements in a row or column of the input matrix
			while (counter < input_matrix.length) 
			{

				//Initialize a minimum variable to Integer.Max_Value or 9999 or any big number
				int min = 9999;

				//Find the minimum element of the distance array 
				//				for (int m = 0; m < distance_array.length; m++) {
				//					
				//					if (!visit_array[m] && distance_array[m] != -1 && m != index) {
				//				
				//						if (distance_array[m] < min) {
				//							min = distance_array[m];
				//							index = m;
				//						}
				//					}
				//				}
				int m=0;
				while(m<distance_array.length)
				{
					if(visit_array[m]==false)
					{
						if(distance_array[m]!=-1)
						{
							if(m!=index)
							{
								if(distance_array[m]<min)
								{
									min=distance_array[m];
									index=m;
								}
							}
						}
					}
					m++;
				}

				//If a direct path exists, break from the loop
				if (index == destination) 
				{
					break;
				}

				//Initialize the index of the minimum element in the visit array as true
				visit_array[index] = true;
				counter++;

				//Find the path and cost from the node containing the minimum element
				//				for (int i = 0; i < distance_array.length; i++) {
				//					
				//					if ((distance_array[i] == -1 && input_matrix[index][i] != -1 && ! visit_array[i]))
				//					{
				//						distance_array[i] = distance_array[index] + input_matrix[index][i];
				//						path_array[i] = index;
				//					}
				//					
				//					else if((input_matrix[index][i] != -1 && distance_array[index] + input_matrix[index][i] < distance_array[i])){
				//						distance_array[i] = distance_array[index] + input_matrix[index][i];
				//						path_array[i] = index;
				//					
				//					}
				//				}
				int n=0;
				while(n<distance_array.length)
				{
					if(distance_array[n]==-1)
					{
						if(input_matrix[index][n]!=-1)
						{
							if(visit_array[n]==false)
							{
								distance_array[n]=distance_array[index]+input_matrix[index][n];
								path_array[n]=index;
							}
						}
					}
					else if(input_matrix[index][n]!=-1)
					{
						if(distance_array[index] + input_matrix[index][n] < distance_array[n])
						{
							distance_array[n] = distance_array[index] + input_matrix[index][n];
							path_array[n] = index;
						}
					}
					n++;
				}


			}
			//Holds the final route
			int[] route = new int[input_matrix.length]; 
			int d = destination;
			route[0]=d;

			List<Object> routerList = new ArrayList<Object>();
			while (path_array[d] != source) 
			{
				d = path_array[d];
				route[k] = d;
				k++;
			}
			route[k] = source;
			//			for (int j = k; j > 0; j--)
			//			{	
			//				routerList.add(route[j]+1);
			//			}
			RouterCollection collection=new RouterCollection();
			int j=0;
			while( j>0)
			{
				j=k;
				routerList.add(route[j]+1);
				//collection.addRouterList(route[j]+1);
				j--;
			}
			al.add(distance_array[source]);
			al.add(distance_array[destination]);
			al.add(routerList);

			System.out.println(distance_array[source]);
			//collection.getRouteList().add(distance_array[source]);
			//collection.addRouteList(0);
			//System.out.println("hhhhhhhhhh"+collection.routeList.get(0));
			//			collection.routeList.add(distance_array[source]);
			//			collection.routeList.add(distance_array[destination]);
			//			collection.routeList.add(collection.routerList);
			//			//collection.addRouteList(distance_array[destination]);
//			for(int a=0;a<collection.routeList.size();a++)
//			{
//				System.out.println("List"+collection.routeList.get(a));
//			}
			return al;

		}
		catch(Exception e){
			e.printStackTrace();
		}

		return null;
	}

}
