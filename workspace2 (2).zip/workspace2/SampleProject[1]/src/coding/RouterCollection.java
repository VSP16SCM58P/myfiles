package coding;

import java.util.ArrayList;

public class RouterCollection {
	//private int router;
	ArrayList<Object> routerList;
	ArrayList<Object> routeList;
	public Object addRouterList(int router)
	{
		 routerList.add(router);
		 return routerList;
	}
	public Object addRouteList(int pathRouter)
	{
		routeList.add(pathRouter);
		System.out.println("herrr"+routeList.get(0));
		return routeList;
	}
	public ArrayList<Object> getRouterList() {
		return routerList;
	}
	public void setRouterList(ArrayList<Object> routerList) {
		this.routerList = routerList;
	}
	public ArrayList<Object> getRouteList() {
		return routeList;
	}
	public void setRouteList(ArrayList<Object> routeList) {
		this.routeList = routeList;
	}

}
