package coding;
import java.util.*;
import java.util.prefs.PreferenceChangeEvent;

import javax.print.attribute.standard.Destination;import javax.sound.sampled.Line;
public class DA
{
	public  int distance[]; 
	public int[] route;
	List<Integer> routerList = new ArrayList<Integer>();
	List<Object> finalList = new ArrayList<Object>();

	public List<Object> calc(int[][]matrix,int n,int s,int d)
	{
		try
		{
			int[] preD = new int[n];
			int min = Integer.MAX_VALUE, nextNode = 0; 
			int[] distance = new int[n]; 
			boolean[] flag = new boolean[n]; 
			

			for(int i = 0; i < distance.length; i++){

				flag[i] = false; //initialize flag array to zeros

				preD[i] = 0;

				for(int j = 0; j < distance.length; j++){

					//matrix[i][j] = scan.nextInt(); //fill the matrix

					if(matrix[i][j]==0 || matrix[i][j]==-1){

						matrix[i][j] = Integer.MAX_VALUE; // make the zeros as 999

					}

				}

			}

			distance = matrix[s]; //initialize the distance array
			flag[s] = true; //set the source node as flag
			distance[s] = 0; //set the distance from source to source to zero which is the starting point

			for(int counter = 0; counter < n; counter++){

				min = Integer.MAX_VALUE;

				for(int i = 0; i < n; i++){

					if(min > distance[i] && flag[i]!=true){

						min = distance[i];
						nextNode = i;

					}

				}

				flag[nextNode] = true;
				if(nextNode==d)
				{
					break;

				}
				for(int i = 0; i < n; i++)
				{

					if(flag[i]!=true)
					{

						if(min+matrix[nextNode][i] < distance[i])
						{

							distance[i] = min+matrix[nextNode][i];
							preD[i] = nextNode;

						}

					}

				}

			}

			for(int i = 0; i < n; i++){
				if(i==d)
				{

					System.out.print("|" + distance[i]);
				}

			}
			System.out.println("|");

			int j;
			for(int i = 0; i < n; i++){
				if(i==d){
					System.out.print("Path = " + (i+1));
					j = i;
					do{

						j=preD[j];
						System.out.print(" <--" + (j+1));

					}while(j!=0);
					System.out.println("\tCost"+distance[i]);
				}
				finalList.add(distance);
				finalList.add(preD);
				System.out.println();

			}
			return finalList;
		}
		catch(Exception c)
		{
			c.printStackTrace();
		}
		return null;
	}
	public int[] getPathTrace(int[] preD)
	{
		return preD;
	}
}