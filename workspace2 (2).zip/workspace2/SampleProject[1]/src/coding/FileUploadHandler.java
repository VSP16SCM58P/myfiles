package coding;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.FileItemFactory;
import org.apache.tomcat.util.http.fileupload.FileItemIterator;
import org.apache.tomcat.util.http.fileupload.FileItemStream;
import org.apache.tomcat.util.http.fileupload.FileUploadException;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

/**
 * Servlet to handle File upload request from Client
 * @author Javin Paul
 */
@SuppressWarnings("serial")
public class FileUploadHandler extends HttpServlet {
	private static final long serialVersionUID = 1L;         
	private final String UPLOAD_DIRECTORY = "C:/Uploads";
	
	//SaveData sd=new SaveData();
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
			int[][] matrix =null;
		if (ServletFileUpload.isMultipartContent(request)) 
		{
			FileItemFactory factory = new DiskFileItemFactory();                
			 // Create a new file upload handler                
		     ServletFileUpload upload = new ServletFileUpload(factory);
				
			ServletFileUpload fileUpload = new ServletFileUpload();
			FileItemIterator items;
			try {
				items = fileUpload.getItemIterator(request);
				
//				String name = new File(item.getName()).getName();
//				//item.write( new File(UPLOAD_DIRECTORY + File.separator+name));
//                String filePath = UPLOAD_DIRECTORY + File.separator+name;
//                System.out.println("FilePath:: "+filePath);
				while (items.hasNext()) 
				{
					
					FileItemStream item1 = items.next();
					Scanner fileScanner = new Scanner(new File(item1.getName()));
					int intLength = 0;
					String[] length = fileScanner.nextLine().split("\\s+");
					  for (int i = 0; i < length.length; i++) {
					    intLength++;
					  }

					  fileScanner.close();

					matrix = new int[intLength][intLength];
					fileScanner = new Scanner(new File(item1.getName()));

					int lineCount = 0;
					while (fileScanner.hasNextLine()) {
					  String[] currentLine = fileScanner.nextLine().trim().split("\\s+"); 
					     for (int i = 0; i < currentLine.length; i++) {
					        matrix[lineCount][i] = Integer.parseInt(currentLine[i]);    
					            }
					  lineCount++;
					 }            
					System.out.println("Len");
					      //sd.Save(matrix);
					     
							request.setAttribute("message", matrix);
							request.setAttribute("row", lineCount);
							request.setAttribute("column",intLength);
							
					
				}
			}
				catch (FileUploadException e)
				{
					// TODO Auto-generated catch block
					request.setAttribute("message", "File not Upload"+e);
				}

			}
		
			request.getRequestDispatcher("/ViewTopology.jsp").forward(request, response);
	}

}
