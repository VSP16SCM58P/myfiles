package coding;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Arrays;

import java.util.Scanner;



public class project
{

	/**
	 * @param args
	 */

	static String[] edges = new String[100];

	public static int del = 0;

	public static String delarray[] = new String[10];

	static int j=0;

	public static String[][] ve= new String[20][2];

	public static int[][] s= new int[20][2];

	public static int[] vd = new int[20];

	public static int no = 0,no1=0,gn=0;

	public static String path[] = new String[100];

	public static String[][] E = new String[20][3]; 

	static String graph[][] = new String[100][100];
	static int a;

	public static int search(String str)

	{

		int i = 0;

		for(i=0;i<100;i++)

		{

			if(edges[i].equals(str))

			{

				break;

			}

		}

		return i;

	}

	public static int extract(int k)

	{

		int i,j,key,keys;

		for(i=0;i<no;i++)

		{

			s[i][0]=vd[i];

			s[i][1]=i;	

		}

		for(j=1;j<no;j++)

		{

			key=s[j][0];

			keys=s[j][1];

			i=j-1;

			while((i>0)&&(s[i][0]>key))

			{

				s[i+1][0]=s[i][0];

				s[i+1][1]=s[i][1];

				i=i-1;

			}

			s[i+1][0]=key;

			s[i+1][1]=keys;

		}

		return (s[k][1]);


	}

	public static void initilize_single_source(String a)

	{


		int i=0;
		//			
//		for(i=0;i<no1;i++)         
//		{
//			//       	   	
//			removeedge(vd[search(E[i][0])],vd[search(E[i][1])]);
//		//       	   	
//		//System.out.println(v[search(E[i][0])]+"-"+v[search(E[i][1])]);
//		//          	
//	}

	for(i=0;i<no;i++)
	{

		vd[i]=99;

	}
	vd[find(a)]=0;

}

public static int find(String a)

{
	int i=0,b = 0;
	for(i=0;i<no;i++)
	{
		if(ve[i][0].equals(a))
		{
			b=i;
		}	
	}
	return b;
}
public static void Relax(String a,String b,int w)
{
	if(vd[find(b)]>vd[find(a)]+w)
	{
		vd[find(b)]=vd[find(a)]+w;
		ve[find(b)][1]=ve[find(a)][0];
	}
}
public static void dijkstra(String a)
{
	String u;
	int w;
	initilize_single_source(a);
	int i, k=0;
	for(j=0;j<no;j++)
	{
		u=ve[extract(k)][0];
		k++;
		for(i=0;i<no1;i++)
		{
			if(E[i][0].equals(u))
			{
				w=Integer.parseInt(E[i][2]);
				Relax(E[i][0],E[i][1],w);
			}
		}					  
	}
}
public static void path(String s, String d)
{
	dijkstra(s);
	String pa; 
	path[0]=d;
	pa = d;
	a=1;
	int i;
	do
	{
		pa = ve[search(pa)][1];
		path[a]=pa;
		a++;
	}while(!pa.equals(s));
	System.out.print("Path is: ");
	for(i=a-1;i>=0;i--){
		if(i==0)
			System.out.print(path[i]);
		else
			System.out.print(path[i]+"->");
	}
	System.out.println("  Cost is - "+vd[find(d)]);
}
public static void routingTable(String s){
	dijkstra(s);
	String pa; 
	int i;
	System.out.println("Router"+s+" Connection Table: ");
	System.out.println("Destination  Interface");
	System.out.println("======================");
	System.out.println("    "+s+"          -");
	for(i=0;i<no;i++){
		if(!edges[i].equals(s)){
			String d =edges[i];
			path[0]=d;
			pa = d;
			a=1;
			do
			{
				pa = ve[search(pa)][1];
				path[a]=pa;
				a++;
			}while(!pa.equals(s));
			System.out.println("    "+s+"          "+path[a-2]);
		}
	}
}
public static void remove(String r){
	delarray[del]=r;
	del++;
	for(int i=0;i<no;i++){
		if(edges[i].equals(r)){
			ve[i][0]=ve[no-1][0];
			ve[i][1]=ve[no-1][1];     
			edges[i]=edges[no-1];
			no--;
		}
	}
	for(int i=0;i<no1;i++){
		if(E[i][0].equals(r)||E[i][1].equals(r)){
			E[i][0] = E[no1-1][0];
			E[i][1] = E[no1-1][1];
			E[i][2] = E[no1-1][2];
			no1--;
		}
	}
}
public static void print(){
	for(int i=0;i<gn;i++){
		if(!Arrays.asList(delarray).contains(""+(i+1)))
		{
			for(int j=0;j<gn;j++){
				if(!Arrays.asList(delarray).contains(""+(j+1))){
					System.out.print(graph[i][j]+" ");
				}
			}
			System.out.println("");
		}
	}
}
public static void main(String[] args) {
	// TODO Auto-generated method stub
	int i=0,j=0,k=0;
	//		for(i=0;i<no;i++)
	//			System.out.println(edges[i]);
	//		for(i=0;i<no1;i++){
	//			System.out.println(E[i][0]+"-"+E[i][1]+","+E[i][2]);
	//		}

	String s = null,d = null;
	@SuppressWarnings("resource")
	Scanner sc = new Scanner(System.in); 
	int input=0;
	while(input!=5){
		System.out.println("Enter (1) Create a Network Topology \nEnter (2) Build a Connection Table \nEnter (3) Shortest Path to Destination Router \nEnter (4) Modify a topology\nEnter (5) Exit");
		input = sc.nextInt();
		if(input == 1){
			try{
				System.out.println("Please Enter the path of the text file");
				String path = sc.next();
				FileInputStream fstream = new FileInputStream(path);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String strLine;
				String[] words;
				i=0;
				j=0;
				while((strLine=br.readLine())!=null)
				{
					//					  System.out.println(strLine);
					words = strLine.split(" ");
					k=0;
					for(String word : words)
					{
						if(!(word.equals("-1") || word.equals("0"))){
							// System.out.println(word);
							E[j][0] = ""+(i+1);
							E[j][1] = ""+(k+1);
							E[j][2] = word;	
							//Edge input
							j++;

						}
						graph[i][k]=word;
						k++;
					} 
					i++;
				}
				no=i;
				no1=j;
				gn=i;
				for(i=0;i<no;i++)
				{
					ve[i][0]=""+(i+1);
					ve[i][1]=""+(i+1);     
					edges[i]=""+(i+1);
				}
				in.close();
			}catch (Exception e){
				System.err.println("Error: " + e.getMessage());
			}
			print();
		}
		if(input == 2){
			System.out.println("Select a source router:");
			s=sc.next();
			routingTable(s);
		}
		if(input == 3){
			System.out.println("Select a source router:");
			s=sc.next();
			System.out.println("Select the destination router:");
			d=sc.next();
			path(s,d);
		}
		if(input == 4){
			System.out.println("Select a router to be removed:");
			s=sc.next();
			remove(s);
			print();
		}
	}
}

}
