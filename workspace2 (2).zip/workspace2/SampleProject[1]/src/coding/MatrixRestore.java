package coding;

import java.util.ArrayList;

public class MatrixRestore {

	public int[][] matrixRestoreWithRouter(int[][] old_matrix,int[][] modifies_matrix,int routerNo )
	{
		ArrayList<Integer> deletedList = new ArrayList<Integer>();
		int count=0;

		//		for(int i=0;i<modifies_matrix.length;i++)
		//		{
		//			for(int j=0;j<modifies_matrix.length;j++)
		//			{
		//				if(modifies_matrix[i][j]==-1)
		//				{
		//					count++;
		//					for(int k=0;k<modifies_matrix.length;k++)
		//					{
		//						if(modifies_matrix[k][i]==-1 && count==modifies_matrix.length)
		//						{
		//							deletedList.add(i+1);
		//						}
		//					}
		//				
		//				}
		//			}
		//		}



		////			
		////		}
		//check for deleted elements
		int i=0;
		while(i<modifies_matrix.length)
		{
			count =0;
			for(int j=0;j<modifies_matrix.length;j++)
			{
				if(modifies_matrix[i][j]==-1)
				{
					count++;
					if(count==modifies_matrix.length-1)
					{
						deletedList.add(i+1);	
					}
				}
			}
			i++;
		}
		//deleted router element from list 
		System.out.println("Size::"+deletedList.size());
		for(int k=0;k<deletedList.size();k++)
		{
			System.out.println("dlist"+deletedList.get(k));
			if(deletedList.get(k)==routerNo)
			{
				deletedList.remove(k);
			}
		}



		//row wise
		for(int n=0;n<modifies_matrix.length;n++)
		{
			for(int m=0;m<deletedList.size();m++)
			{
				if(n!=deletedList.get(m))
				{
					modifies_matrix[n][routerNo]=old_matrix[n][routerNo];
				}
				//				if(n==deletedList.get(m)){
				//					modifies_matrix[deletedList.get(m)][routerNo]=-1;
				//					modifies_matrix[routerNo][deletedList.get(m)]=-1;
				//					
				//				}
			}

		}
		//column wise
		for(int n=0;n<modifies_matrix.length;n++)
		{
			for(int m=0;m<deletedList.size();m++)
			{
				if(n!=deletedList.get(m))
				{
					modifies_matrix[routerNo][n]=old_matrix[routerNo][n];
				}
				//				if(n==deletedList.get(m)){
				//					modifies_matrix[deletedList.get(m)][routerNo]=-1;
				//					modifies_matrix[routerNo][deletedList.get(m)]=-1;
				//				}
			}

		}

		for(int x=0;x<modifies_matrix.length;x++)
		{
			for(int m=0;m<modifies_matrix.length;m++)
			{ 
				for(int y=0;y<deletedList.size();y++)
				{
					if(x==deletedList.get(y) || m==deletedList.get(y))
					{
					modifies_matrix[m][deletedList.get(y)]=-1;
					modifies_matrix[deletedList.get(y)][m]=-1;
					}
				}
			}

		}
		return modifies_matrix;
	}
}