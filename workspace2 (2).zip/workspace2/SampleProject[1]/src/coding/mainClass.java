//package coding;
//
//public class mainClass {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//      FindShortestPath path=new FindShortestPath(10);
//     
//      int [][] matrix = {{0,4,-1,2,-1 },{4,0,8,-1,5},{-1,8,0,3,-1},{2,-1,3,0,4},{-1,5,-1,4,0}};
//      path.shortestPathBtwNodes(matrix, 2, 3);
//      
//	}
//
//}
