package coding;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ShortestPath extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static Scanner file;
	static int rows;
	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		
		ArrayList<ArrayList<Integer>> data = new ArrayList<ArrayList<Integer>>();
		//PrintWriter out = response.getWriter();
		//int row = (int) request.getSession().getAttribute("row");
		String path = (String) request.getServletContext().getAttribute("Upload_Directory");
		int[][] matrix = (int[][]) request.getServletContext().getAttribute("message");
		int name;
		int lineCount=0;
		String line = null;
		BufferedReader br = new BufferedReader(new FileReader(path));
		while((line=br.readLine())!=null){
			lineCount++;
		}
		int source=Integer.parseInt(request.getParameter("Source"))-1;
		int destination=Integer.parseInt(request.getParameter("Destination"))-1;
		System.out.println("S"+source+"Destination"+destination);
		int[] trace = new int[lineCount];
		int min = 999, nextNode = 0; 
		int[] distance = new int[lineCount]; 
		boolean[] flag = new boolean[lineCount]; 
		try
		{
			
			

			for(int i = 0; i < distance.length; i++){

				flag[i] = false; //initialize flag array to zeros

				trace[i] = 0;

				for(int j = 0; j < distance.length; j++){

					//matrix[i][j] = scan.nextInt(); //fill the matrix

					if(matrix[i][j]==0 || matrix[i][j]==-1){

						matrix[i][j] = 999; // make the zeros as 999

					}

				}

			}

			distance = matrix[source]; //initialize the distance array
			flag[source] = true; //set the source node as flag
			distance[source] = 0; //set the distance from source to source to zero which is the starting point

			for(int counter = 0; counter < lineCount; counter++){

				min = 999;

				for(int i = 0; i < lineCount; i++){

					if(min > distance[i] && flag[i]!=true){

						min = distance[i];
						nextNode = i;

					}

				}

				flag[nextNode] = true;
				
				for(int i = 0; i < lineCount; i++)
				{

					if(flag[i]!=true)
					{

						if(min+matrix[nextNode][i] < distance[i])
						{

							distance[i] = min+matrix[nextNode][i];
							trace[i] = nextNode;

						}

					}

				}

			}

			
			
		}
		catch(Exception c)
		{
			c.printStackTrace();
		}

		request.getServletContext().setAttribute("count", lineCount);
		request.getServletContext().setAttribute("source",source);
		request.getServletContext().setAttribute("dest",destination);
		request.getServletContext().setAttribute("path",trace);
		request.getServletContext().setAttribute("distance",distance);
		
		
		request.getServletContext().setAttribute("matrix",matrix);
		
	
		request.getRequestDispatcher("/DisplayShortestPath.jsp").forward(request, response);
	}

}
