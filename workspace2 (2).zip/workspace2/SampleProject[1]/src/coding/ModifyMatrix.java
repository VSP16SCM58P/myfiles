package coding;

public class ModifyMatrix {
	public int[][] modifiedMatrix(int[][] matrix,int routerNumber)
	{
		int modifiedMatrix[][]=new int[matrix.length][matrix.length];
		for(int i=0;i<matrix.length;i++)
		{
			for(int j=0;j<matrix.length;j++)
			{
				if(routerNumber==i || routerNumber==j)
				{
					modifiedMatrix[i][j]=-1;
				System.out.println(modifiedMatrix[i][j]);
				}
				else
				{
					modifiedMatrix[i][j]=matrix[i][j];
					System.out.println(modifiedMatrix[i][j]);	
				}
			}
		}
		
		
		
		return modifiedMatrix;
		
	}

}
