package coding;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.FileItemStream;

public class RoutingTable extends HttpServlet 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Scanner file;
	static int rows;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		ArrayList<ArrayList<Integer>> data = new ArrayList<ArrayList<Integer>>();
		//PrintWriter out = response.getWriter();
		//int row = (int) request.getSession().getAttribute("row");
		String path = (String) request.getServletContext().getAttribute("Upload_Directory");
		int[][] matrix = (int[][]) request.getServletContext().getAttribute("message");
		int name;
		name = Integer.parseInt(request.getParameter("routerNo"));
		System.out.println("Path::"+name);
		int routerN = name;
		String line = null;
		int lineCount=0;

		BufferedReader br = new BufferedReader(new FileReader(path));
		while((line=br.readLine())!=null){
			lineCount++;
		}
		System.out.println("Connection Table");
		// ArrayList routers = new ArrayList();
		//ArrayList edges = new ArrayList();
		for(int j=0;j<lineCount;j++){
			if(matrix[routerN-1][j]==0){
				System.out.println("Router"+j+"----> -");
				//routers.add(j);
				// edges.add(0);
			}
			else if(matrix[routerN-1][j] > 0){
				System.out.println("Router"+j+"---->"+matrix[name-1][j]);
				// routers.add(j);
				//edges.add(matrix[name][j]);
			}
			else if(matrix[routerN-1][j]==-1){
				System.out.println("Router"+j+"---->Not Connected");
				//routers.add(j);
				// edges.add(-1);
			}
		}
		//        for(int i=0;i<routers.size();i++)
		//        {
		//        	System.out.println(routers.get(i)+"----->"+edges.get(i));
		//        }
		System.out.println("Row:"+lineCount);

		request.setAttribute("Count", lineCount);
		request.getServletContext().setAttribute("rout", routerN);
		request.getServletContext().setAttribute("matrix",matrix);
		//    request.setAttribute("routerList", routers);
		//    request.setAttribute("edgesList", edges);

		request.getRequestDispatcher("/RouterTable.jsp").forward(request, response);
	}


}