package coding; 

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 * Servlet to handle File upload request from Client
 * @author Javin Paul
 */
public class FileUpload extends HttpServlet {
    private final String UPLOAD_DIRECTORY = "C:/uploads";
    String name;
  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      
    	int[][] matrix =null;
    	
        //process only if its multipart content
        if(ServletFileUpload.isMultipartContent(request)){
            try {
                List<FileItem> multiparts = new ServletFileUpload(
                                         new DiskFileItemFactory()).parseRequest(request);
              
                for(FileItem item : multiparts){
                    if(!item.isFormField()){
                        name = new File(item.getName()).getName();
                        item.write( new File(UPLOAD_DIRECTORY + File.separator + name));
                    }
                }
                
                Scanner fileScanner = new Scanner(new File(UPLOAD_DIRECTORY + File.separator + name));
                int intLength = 0;
				String[] length = fileScanner.nextLine().split("\\s+");
				  for (int i = 0; i < length.length; i++) {
				    intLength++;
				  }

				  fileScanner.close();
				  
				  matrix = new int[intLength][intLength];
					fileScanner = new Scanner(new File(UPLOAD_DIRECTORY + File.separator + name));

					int lineCount = 0;
					while (fileScanner.hasNextLine()) {
					  String[] currentLine = fileScanner.nextLine().trim().split("\\s+"); 
					     for (int i = 0; i < currentLine.length; i++) {
					        matrix[lineCount][i] = Integer.parseInt(currentLine[i]);    
					            }
					  lineCount++;
					 }            
					System.out.println("Len");
					      //sd.Save(matrix);
					     	request.getServletContext().setAttribute("Upload_Directory", UPLOAD_DIRECTORY + File.separator + name);
							request.getServletContext().setAttribute("message", matrix);
							request.getServletContext().setAttribute("row", lineCount);
							request.getServletContext().setAttribute("column",intLength);
            } catch (Exception ex) {
               request.setAttribute("message", "File Upload Failed due to " + ex);
            }          
         
        }else{
            request.setAttribute("message",
                                 "Sorry this Servlet only handles file upload request");
        }
    
        request.getRequestDispatcher("/ViewTopology.jsp").forward(request, response);
     
    }
  
}


