package coding;

public class EdgeModificationClass {

	public int[][] edgeModification(int matrix[][],int edgeValue1,int edgeValue2,int cost)
	{
		//int newMatrix[][]=new int[matrix.length][matrix.length];
		for(int i=0;i<matrix.length;i++)
		{
			for(int j=0;j<matrix.length;j++)
			{
				if((edgeValue1-1)==i && (edgeValue2-1)==j)
				{
					matrix[i][j]=cost;
				}
			}
		}
		return matrix;
		
	}
}
