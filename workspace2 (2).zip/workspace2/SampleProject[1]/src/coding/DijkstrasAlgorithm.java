package coding;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DijkstrasAlgorithm {
	public void shortestPath(int[][] matrix,int s,int d,int l)
	{
		int length=l;
		System.out.println("len"+l);
		int[] distance=new int[l];
		int[] visited=new int[l];
		int[] trace=new int[l];
		int min = 0;
		int nextNode=0;
		for(int i=0;i<distance.length;i++)
		{
			visited[i]=0;
			trace[i]=0;
			for(int j=0;j<distance.length;j++)
			{
				if(matrix[i][j]==0 || matrix[i][j]==-1)
				{
					matrix[i][j]=999;
				}
				System.out.print("\t"+matrix[i][j]);
			}
			System.out.println();
		}
		distance=matrix[s];
		distance[s]=0;
		visited[s]=1;
		for(int counter=0;counter<l;counter++)
		{
			min=999;
			for(int j=0;j<l;j++)
			{
				if(min>distance[j] && visited[j]!=1)
				{
					min=distance[j];
					nextNode=j;
				}
			}
		}
		visited[nextNode]=1;
		for(int c=0;c<l;c++)
		{
			if(visited[c]!=1)
			{
				if(min+matrix[nextNode][c]<distance[c])
				{
					trace[c]=nextNode;
				}
			}
		}

		for(int i=0;i<l;i++)
		{
			System.out.println("|"+distance[i]);
		}
		for(int i=0;i<5;i++)
		{
			int j;
			System.out.println("Path"+i);
			j=i;
			do
			{
				j=trace[j];
				System.out.println("<---"+j);

			}while(j!=0);
			System.out.println();
		}
	}
	public static void main(String[] args)
	{
		int s=0;
		int d=4;
		int adjacency_matrix[][]=new  int[5][5];
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the Cost Matrix Weights: \n");
		for(int i=1;i<=5;i++)
		{
			for(int j=1;j<=5;j++)
			{
				 adjacency_matrix[i][j]=in.nextInt();
			}
		}
		DijkstrasAlgorithm algorithm=new DijkstrasAlgorithm();
		algorithm.shortestPath(adjacency_matrix, 1, 4, 5);
		//	while(d!=s)
		//	{
		//		list.add(e)
		//	}


	}	
}
