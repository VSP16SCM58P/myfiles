package coding;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class SaveData {
	public void Save(int[][] a){

		try {
			PrintWriter writer = new PrintWriter(new File("C:/Users/vikasprathap/Desktop/t.txt"));

			for(int i=0; i<a.length; i++){
				for(int j=0; j<a[i].length; j++){

					//use this if your array has (int,double..)
					// writer.write(String.valueOf(a[i][j])+" "); //Here you parse the int from array to String.


					//use this if your array has String
					writer.write(a[i][j]+" "); //Its String so you dont have to use String.valueOf(something(int,double,...)
				}
				writer.println(); //leave one line 
			}

			writer.flush();  //flush the writer
			writer.close();  //close the writer      



		} catch (FileNotFoundException e) {      
			e.printStackTrace();
		}
	}
}
