package coding;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class Dijkstras_Shortest_Path
{
	int distance[];
	Boolean visitedNode[];
	int prev[];
	int vertexQueue[];
	List<Integer> traceRoute = new ArrayList<Integer>();
	int next;

	public Dijkstras_Shortest_Path(int number_of_nodes)
	{
		//this.number_of_nodes = number_of_nodes;

		// adjacency_matrix = new int[number_of_nodes + 1][number_of_nodes + 1];
	}

	public int[] dijkstra_algorithm(int adjacency_matrix[][], int source,int destination,int number_of_nodes)
	{

		List<Integer> nr = new ArrayList<Integer>();
		List<Integer> vetexQueue = new ArrayList<Integer>();
		List<Integer> traceRoute = new ArrayList<Integer>();

		distance=new int[number_of_nodes];
		visitedNode=new Boolean[number_of_nodes];
		prev=new int[adjacency_matrix.length];
		vertexQueue=new int[adjacency_matrix.length];
		int dist=0;
		//traceRoute=new int[adjacency_matrix.length];

		for(int i=0;i<number_of_nodes;i++)
		{
			distance[i]=9999;
			visitedNode[i]=false;
			//vertexQueue[i]=i;

		}
		distance[source]=0;
		vetexQueue.add(source);
		for(int i=0;i<distance.length;i++)
		{
			
			next=FindMinDistRouter(adjacency_matrix,visitedNode);
			visitedNode[next]=true;
			//vetexQueue.remove(next);
//			if(next==destination)
//			{
//				break;
//			}
			nr=FindNeighbour(adjacency_matrix, next);
			for(int j=0;j<nr.size();j++)
			{
				int v=nr.get(j);
				int d=distance[next]+adjacency_matrix[next][v];
				if(distance[v]>d && visitedNode[v]==true && adjacency_matrix[next][v]!=-1 && distance[next]!=9999 )
				{
					distance[v]=d;
					prev[v]=next;

					System.out.println("distance"+distance[v]);
					System.out.print("Previous Value-->"+prev[v]);
				}
			}
		}
		int sum=0;

		System.out.print("connecting"+sum);
		return prev;
	}
	private int FindMinDistRouter(int[][] adjacency_matrix,Boolean[] visitedNode) 
	{

		// TODO Auto-generated method stub

		int index=-1;
		int x=Integer.MAX_VALUE;
		for(int i=0;i<distance.length;i++)
		{
			if(visitedNode[i]==false && distance[i]<x )
			{
				index=i;
				x=distance[i];
			
			}
		}
		
		return index;	
	}

	public List<Integer> FindNeighbour(int[][]adjacency_matrix,int source)
	{
		List<Integer> r = new ArrayList<Integer>();
		for(int i=0;i<adjacency_matrix.length;i++)
		{
			if(adjacency_matrix[source][i]>0)
			{
				r.add(i);
				System.out.println("List"+i);
			}
		}
		
		return r;

	}
	public static void main(String[] args)
	{
		int s=0;
		int d=4;
		int adjacency_matrix[][]={{0,4,-1,2,-1}, 
				{4,0,8,-1,5},
				{-1,8,0,3,-1},
				{2,-1,3,0,4},
				{-1,5,-1,4,0}}; 
		Dijkstras_Shortest_Path path=new Dijkstras_Shortest_Path(5);
		path.dijkstra_algorithm(adjacency_matrix,0,4,5);
		//		DA da=new DA();
		//		da.dijkstras(adjacency_matrix,0,4);
		List<Integer> list=new ArrayList<Integer>();
		//	while(d!=s)
		//	{
		//		list.add(e)
		//	}


	}	

}